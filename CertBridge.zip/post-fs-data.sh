#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/bin/common.sh"

POST_HAS_LOCK=0
post_cleanup() {
  if [ "$POST_HAS_LOCK" = "1" ]; then
    release_write_lock
    POST_HAS_LOCK=0
  fi
}
trap post_cleanup 0
trap 'post_cleanup; exit 1' 1 2 15

log_msg "post-fs-data start (api=$(get_api))"
# 软重启不换内核 boot_id：先递增 epoch，立刻让旧 runtime-status / 热会话缓存失效
bump_boot_epoch
update_module_description "启动中"
if ! acquire_write_lock; then
  write_inject_error lock_timeout
  log_msg "post-fs-data: lifecycle lock timeout"
  finalize_runtime_status post-fs-data >/dev/null
  exit 1
fi
POST_HAS_LOCK=1
if [ -x "$BINDIR/hot_mount.sh" ]; then
  if ! CERTBRIDGE_LOCK_HELD=1 sh "$BINDIR/hot_mount.sh" unmount_locked >/dev/null 2>&1; then
    write_inject_error hot_unmount_failed
    log_msg "post-fs-data: stale hot session cleanup failed"
    finalize_runtime_status post-fs-data >/dev/null
    exit 1
  fi
else
  log_msg "post-fs-data: hot reload component not installed"
fi
# 按挂载模式准备 / 清理模块 system 叠层（magic 仅 addon；compatible 必须清空）
if ! prepare_mount_mode_overlay "$MODDIR"; then
  write_inject_error overlay_prepare_failed
  log_msg "post-fs-data: prepare_mount_mode_overlay failed"
  finalize_runtime_status post-fs-data >/dev/null
  exit 1
fi
# 软重启后上一轮 apex/system bind 可能仍在；先卸掉再读真实系统 CA，
# 否则已关闭的 ProxyPin 等 addon 会污染新 generation（日志里仍出现 243f0bfb.0）
detach_runtime_cacert_binds || \
  log_msg "post-fs-data: detach runtime binds soft-fail"
if ! build_boot_generation; then
  write_inject_error generation_failed
  log_msg "post-fs-data: live generation failed, original store preserved"
  finalize_runtime_status post-fs-data >/dev/null
  exit 1
fi
# generation 后再次同步 magic 叠层，确保与本轮 applied 一致（skip 时不叠 system）
if needs_system_magic_overlay; then
  sync_magic_overlay "$MODDIR" >/dev/null || \
    log_msg "post-fs-data: magic overlay resync soft-fail"
fi
rm -f "$INJECT_FAIL_FILE"
if sh "$MODDIR/bin/apex_inject.sh" boot; then
  clear_inject_error
else
  commit_inject_fail boot_inject_failed
  log_msg "post-fs-data: boot injection failed"
fi
# 仅标记中间态；不要在此处跑 check_store_injected（zygote 常未就绪，会把 apex_ok 误写成 0）
# 最终「运行正常 / 证书注入失败」必须由 service 的 finalize_runtime_status 写入
write_runtime_status post-fs-data 2 "注入中"
update_module_description "注入中"
post_cleanup
log_msg "post-fs-data done"
